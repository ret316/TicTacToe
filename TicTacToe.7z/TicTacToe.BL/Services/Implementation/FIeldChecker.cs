﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using TicTacToe.BL.Models;
using TicTacToe.DL.Models;

namespace TicTacToe.BL.Services.Implementation
{
    public class FIeldChecker : IFieldChecker
    {
        public char[,] Board { get; set; }
        private IEnumerable<GameHistoryBL> _gameHistory;
        private GameHistoryBL _nextMove;
        private Guid? firstPlayerId;

        public void BoardInit(IEnumerable<GameHistoryBL> gameHistories)
        {
            this._gameHistory = gameHistories;
            Board = new char[IFieldChecker.BOARD_SIZE, IFieldChecker.BOARD_SIZE];
            firstPlayerId = gameHistories.First().PlayerId;
            foreach (var item in gameHistories)
            {
                if (item.PlayerId == firstPlayerId)
                {
                    Board[item.XAxis, item.YAxis] = 'X';
                }
                else
                {
                    Board[item.YAxis, item.YAxis] = 'Y';
                }
            }
        }

        public void NextMoveInit(GameHistoryBL nextMove)
        {
            this._nextMove = nextMove;
        }

        public void DCheck()
        {
            bool oneToNine = false;
            bool threeToSeven = false;
            for (int i = 0, j = IFieldChecker.BOARD_SIZE - 1; i < IFieldChecker.BOARD_SIZE; i++, j--)
            {
                if (i > 0)
                {
                    oneToNine = CompareChar(Board[i, i], Board[i - 1, i - 1]);
                    threeToSeven = CompareChar(Board[j, i], Board[i - 1, j + 1]);
                }
            }

            if (oneToNine || threeToSeven)
            {

            }
        }

        public void DoubleCellCheck()
        {
            if (Board[_nextMove.XAxis, _nextMove.YAxis] == '\0')
            {

            }
        }

        public void EndGameCheck(GameBL game)
        {
            if (game.IsGameFinished)
            {
                
            }
            if (_gameHistory.Count() > Math.Pow(IFieldChecker.BOARD_SIZE, 2))
            {

            }
        }

        public void IndexCheck()
        {
            if (_nextMove.XAxis > IFieldChecker.BOARD_SIZE - 1 || _nextMove.YAxis > IFieldChecker.BOARD_SIZE - 1)
            {

            }
        }

        public void LinesCheck()
        {
            bool xLine = false;
            bool yLine = false;

            for (int i = 0; i < IFieldChecker.BOARD_SIZE; i++)
            {
                for (int j = 0; j < IFieldChecker.BOARD_SIZE; j++)
                {
                    if (j > 0)
                    {
                        xLine = CompareChar(Board[i, j], Board[i, j - 1]);
                    }

                    if (i > 0)
                    {
                        yLine = CompareChar(Board[j, i], Board[j, i - 1]);
                    }
                }

                if (xLine || yLine)
                {

                }
            }
        }

        private bool CompareChar(char current, char previous)
        {
            if (previous == '\0')
            {
                return false;
            }

            return current == previous;
        }

        public void MakeMove()
        {
            Board[_nextMove.XAxis, _nextMove.YAxis] = firstPlayerId.Value == _nextMove.PlayerId ? 'X' : 'Y';
        }
    }
}
