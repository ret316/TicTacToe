﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TicTacToe.BL.Models;
using TicTacToe.DL.Models;
using TicTacToe.DL.Services;

namespace TicTacToe.BL.Services.Implementation
{
    public class GameServiceBL : IGameServiceBL
    {
        private readonly IGameServiceDL _gameServiceDL;
        private readonly IFieldChecker _fieldChecker;
        private readonly IBotService _botService;
        public GameServiceBL(IGameServiceDL gameServiceDL , IFieldChecker fieldChecker, IBotService botService)
        {
            this._gameServiceDL = gameServiceDL;
            this._fieldChecker = fieldChecker;
            this._botService = botService;
        }
        public async Task CreateGameAsync(GameBL game)
        {
            await _gameServiceDL.CreateGameAsync(new GameDL
            {
                Id = Guid.NewGuid(),
                GameId = Guid.NewGuid(),
                Player1Id = game.Player1Id,
                Player2Id = game.Player2Id,
                IsPlayer2Bot = game.IsPlayer2Bot,
                IsGameFinished = false
            });
        }

        public async Task<IEnumerable<GameBL>> GetGamesByGameIdAsync(Guid id)
        {
            var games = await _gameServiceDL.GetGamesByGameIdAsync(id);
            return games.Select(g => new GameBL
            {
                GameId = g.GameId,
                Player1Id = g.Player1Id,
                Player2Id = g.Player2Id,
                IsPlayer2Bot = g.IsPlayer2Bot,
                IsGameFinished = g.IsGameFinished
            });
        }

        public async Task<IEnumerable<GameBL>> GetGamesByUserAsync(Guid id)
        {
            var games = await _gameServiceDL.GetGamesByUserAsync(id);
            return games.Select(g => new GameBL
            {
                GameId = g.GameId,
                Player1Id = g.Player1Id,
                Player2Id = g.Player2Id,
                IsPlayer2Bot = g.IsPlayer2Bot
            });
        }

        public async Task SavePlayerMoveAsync(GameHistoryBL historyBL)
        {
            var historyDL = await _gameServiceDL.GetGameHistoriesAsync(historyBL.GameId);
            var history = historyDL.Select(h => new GameHistoryBL
            {
                GameId = h.GameId,
                PlayerId = h.PlayerId,
                IsBot = h.IsBot,
                XAxis = h.XAxis,
                YAxis = h.YAxis,
                MoveDate = h.MoveDate
            }).ToList();

            if (history.Any())
            {
                var lastMove = history.Last();

                if (lastMove.PlayerId == historyBL.PlayerId || lastMove.IsBot == historyBL.IsBot)
                {
                    return;
                }
            }

            _fieldChecker.BoardInit(history);
            _fieldChecker.NextMoveInit(historyBL);

            var game = (await GetGamesByGameIdAsync(historyBL.GameId)).FirstOrDefault();

            _fieldChecker.EndGameCheck(game);

            if (_fieldChecker.IndexCheck() || _fieldChecker.DoubleCellCheck())
            {
                return "lose";
            }

            if (_fieldChecker.LinesCheck() || _fieldChecker.DCheck())
            {
                return "won";
            }


            _fieldChecker.MakeMove();


            await _gameServiceDL.SavePlayerMoveAsync(new GameHistoryDL
            {
                Id = Guid.NewGuid(),
                GameId = historyBL.GameId,
                PlayerId = historyBL.PlayerId,
                IsBot = historyBL.IsBot,
                XAxis = historyBL.XAxis,
                YAxis = historyBL.YAxis,
                MoveDate = historyBL.MoveDate
            });

            if (historyBL.IsBot)
            {
                //history.Add(historyBL);
                _botService.Board = (char[,])_fieldChecker.Board.Clone();
                _botService.GameHistoryBl = historyBL;
                _botService.GetNextMove();
            }
        }
    }
}
