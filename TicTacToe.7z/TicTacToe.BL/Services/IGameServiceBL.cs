﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using TicTacToe.BL.Models;

namespace TicTacToe.BL.Services
{
    public interface IGameServiceBL
    {
        Task<IEnumerable<GameBL>> GetGamesByUserAsync(Guid id);
        Task<IEnumerable<GameBL>> GetGamesByGameIdAsync(Guid id);
        Task CreateGameAsync(GameBL game);
        Task SavePlayerMoveAsync(GameHistoryBL historyBL);
    }
}
