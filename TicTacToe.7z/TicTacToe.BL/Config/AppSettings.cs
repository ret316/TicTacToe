﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TicTacToe.BL.Config
{
    public class AppSettings
    {
        public string Secret { get; set; }
    }
}
