﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TicTacToe.BL.Models;
using TicTacToe.BL.Services;
using TicTacToe.WebApi.Models;

namespace TicTacToe.WebApi.Services.Implementation
{
    public class GameService : IGameService
    {
        private readonly IGameServiceBL _gameServiceBL;
        public GameService(IGameServiceBL gameServiceBL)
        {
            this._gameServiceBL = gameServiceBL;
        }
        public async Task CreateGameAsync(GameModel game)
        {
            await _gameServiceBL.CreateGameAsync(new GameBL
            {
                Player1Id = game.Player1Id,
                Player2Id = game.Player2Id,
                IsPlayer2Bot = game.IsPlayer2Bot
            });
        }
    }
}
