﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TicTacToe.WebApi.Models;
using TicTacToe.WebApi.Services;

namespace TicTacToe.WebApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GamesController : ControllerBase
    {
        private readonly IGameService _gameService;

        public GamesController(IGameService gameService)
        {
            this._gameService = gameService;
        }

        [HttpPost]
        public async Task CreateGame([FromBody] GameModel gameModel)
        {
            await _gameService.CreateGameAsync(gameModel);
        }

        public async Task PlayerMove()
        {
            
        }

        public async Task GetAllGamesForUser(Guid userId)
        {

        }
    }
}
